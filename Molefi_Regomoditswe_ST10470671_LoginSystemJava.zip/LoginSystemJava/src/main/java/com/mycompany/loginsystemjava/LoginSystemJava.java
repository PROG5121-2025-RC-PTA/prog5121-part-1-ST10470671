/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */ 

package com.mycompany.loginsystemjava;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class LoginSystemJava {
    
   static String storedUsername = "user_1";
    static String storedPassword = "Password1!";
    static String storedFirstName = "";
    static String storedLastName = "";

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {

            // --- Registration Part ---//
            System.out.println("=== User Registration ===");

            System.out.print("Please enter your first name: ");
            storedFirstName = scanner.nextLine();
            System.out.print("Please enter your last name: ");
            storedLastName = scanner.nextLine();

            System.out.print("Create a username (it must include an underscore and be max 5 characters): ");
            String username = scanner.nextLine();
            if (isValidUsername(username)) {
                storedUsername = username;
                System.out.println("Username is captured.");
            } else {
                System.out.println("Username is not formatted correctly . Please make sure it contains an underscore and is no more than five characters long.");
            }

            System.out.print("Create a secure password (min 8 characters, 1 capital letter, 2 number, 1 special character): ");
            String password = scanner.nextLine();
            if (isValidPassword(password)) {
                storedPassword = password;
                System.out.println("Password is successfully captured.");
            } else {
                System.out.println("Password is not correctly formatted. It must have at least 8 characters, a capital letter, a number, and a special character.");
            }

            // --- Login Part ---//
            System.out.println("=== User Login ===");

            System.out.print("Enter your username: ");
            String loginUsername = scanner.nextLine();

            System.out.print("Enter your password: ");
            String loginPassword = scanner.nextLine();

            if (loginUsername.equals(storedUsername) && loginPassword.equals(storedPassword)) {
                System.out.println("Welcome " + storedFirstName + ", " + storedLastName + " it is great to see you again.");
            } else {
                System.out.println("Username or password incorrect, please try again.");
            }
        }
    }

    // --- Username Validation ---//
    public static boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // --- Password Validation ---//
    public static boolean isValidPassword(String password) {
        String regex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+=|<>?{}\\[\\]~-]).{8,}$";
        return pattern.matches(regex, password);
        
        //Referencing from Chatgpt and Youtube brocod.//
    }
}