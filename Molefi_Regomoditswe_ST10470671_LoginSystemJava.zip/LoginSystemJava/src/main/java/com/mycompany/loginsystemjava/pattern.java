/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginsystemjava;

/**
 *
 * @author RC_Student_lab
 */
class pattern {
    public static boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public static boolean isValidPassword(String password) {
        java.util.regex.Pattern regexPattern = java.util.regex.Pattern.compile(
            "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+=|<>?{}\\[\\]~-]).{8,}$"
        );
        java.util.regex.Matcher matcher = regexPattern.matcher(password);
        return matcher.matches();
    }

    public static boolean isValidCellphone(String phone) {
        return phone.matches("^\\+27\\d{9}$");
    }

    static boolean matches(String regex, String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
    

